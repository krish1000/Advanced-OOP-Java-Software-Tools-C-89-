package shape;

public class Square {

}
