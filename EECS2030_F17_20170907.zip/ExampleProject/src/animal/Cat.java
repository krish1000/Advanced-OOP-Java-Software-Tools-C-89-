package animal;

public class Cat {

}
