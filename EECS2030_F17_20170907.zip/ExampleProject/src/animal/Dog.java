package animal;

public class Dog {

}
