package furniture;

public class Chair {

}
