package furniture;

public class Desk {

}
