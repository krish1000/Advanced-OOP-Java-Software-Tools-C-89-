public class TestTwoArrayDictionary extends TestDictionary {
	@Override
	protected Dictionary dict() {
		return new TwoArrayDictionary();
	}
}
