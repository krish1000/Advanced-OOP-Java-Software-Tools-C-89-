
public class B extends A {

}
