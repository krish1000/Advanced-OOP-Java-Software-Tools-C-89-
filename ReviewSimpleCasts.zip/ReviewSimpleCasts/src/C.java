
public class C extends B {

}
