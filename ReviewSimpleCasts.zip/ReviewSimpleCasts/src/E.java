
public class E extends A {

}
