
public class SimpleCastsTester {

	public static void main(String[] args) {
		// C is a descendant of B
		B obj = new C();
		
		// Valid upward casting
		A oa = (A) obj;
		
		// Valid upward casting on the RHS
		// Invalid assignment because
		// cast version has static type A
		// which is not a descendant class
		// of the static type of ob (B).
		// Therefore, the RHS cannot fulfill
		// expectations on ob's static type.
//		B ob = (A) obj;
		
		/*
		 * Compiles because:
		 * 1) the RHS is a valid downward cast
		 * 2) it is a valid assignment because the 
		 * cast version on RHS has static type D, 
		 * which is a descendant class of the static type
		 * of LHS (D).
		 * But executing this line of code will result in
		 * a ClassCastExcpetion, 
		 */
		D od = (D) obj;
		
		// Does not compile because
		// it is neither a upward cast nor a downward cast.
//		E oe = (E) obj;
	}

}
